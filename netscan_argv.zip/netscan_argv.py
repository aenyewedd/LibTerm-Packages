import socket
import sys
import getopt
from datetime import datetime

net = ""
st1 = 0
en1 = 255
port = 0

# Parse arguments

argv = sys.argv[1:]

try:
    opts, args = getopt.getopt(argv,"hr:s:l:p:",["ip=","start=","last=","port="])
except getopt.GetoptError:
    print("Usage: netscan_argv -r <IP address (255.255.255.0 is scanned)> -s <starting number (xxx.xxx.xxx.s-xxx.xxx.xxx.e)> -e <last number (xxx.xxx.xxx.s-xxx.xxx.xxx.e)> -p <port>")
    sys.exit(2)
for opt, arg in opts:
    if opt == '-h':
        print("Usage: netscan_argv -r <IP address (255.255.255.0 is scanned)> -s <starting number (xxx.xxx.xxx.s-xxx.xxx.xxx.e)> -e <last number (xxx.xxx.xxx.s-xxx.xxx.xxx.e)> -p <port>")
        sys.exit()
    elif opt in ("-r", "--ip"):
        net = arg
    elif opt in ("-s", "--start"):
        st1 = int(arg)
    elif opt in ("-l", "--last"):
        en1 = int(arg)
    elif opt in ("-p", "--port"):
        port = int(arg)

# IP address to scan
net1 = net.split('.')
a = '.'

# Create IP address for range scanning
try:
    net2 = net1[0] + a + net1[1] + a + net1[2] + a
except IndexError:
    print("Please enter a valid IP")
    print("Usage: netscan_argv -r <IP address (255.255.255.0 is scanned)> -s <starting number (xxx.xxx.xxx.s-xxx.xxx.xxx.e)> -e <last number (xxx.xxx.xxx.s-xxx.xxx.xxx.e)> -p <port>")
    sys.exit(3)

en1 = en1 + 1
t1 = datetime.now()

# Scan 
def scan(addr):
   s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
   socket.setdefaulttimeout(1)
   result = s.connect_ex((addr, port))
   if result == 0:
      return 1
   else :
      return 0

# Start scan
def run1():
   for ip in range(st1,en1):
      addr = net2 + str(ip)
      if (scan(addr)):
         print(addr , "is up")
         
run1()
t2 = datetime.now()
total = t2 - t1
print ("Scanning completed in: " , total)
